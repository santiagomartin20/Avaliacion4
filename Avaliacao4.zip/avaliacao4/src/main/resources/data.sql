INSERT INTO PARTIDO(id,nome, sigla, ideologia,data_Fundacao) VALUES(0,'', '', 'NULL','2021-11-16');
INSERT INTO ASSOCIADO(id,nome, cargo, sexo,Data_Nacimento) VALUES(0,'', 'NENHUM', 'NULL','2021-11-16');

